import { Component, OnInit } from '@angular/core';
import { HttpClient } from '../../../node_modules/@angular/common/http';
import {JsonObject, JsonProperty, JsonConvert, OperationMode, ValueCheckingMode} from "json2typescript";

@Component({
  selector: 'app-photo-component',
  templateUrl: './photo-component.component.html',
  styleUrls: ['./photo-component.component.css']
})
export class PhotoComponentComponent implements OnInit {

  constructor(private httpclient: HttpClient) { }

  ngOnInit() {
  }

  albumsUrl = "https://jsonplaceholder.typicode.com/albums";
  photosUrl = "https://jsonplaceholder.typicode.com/photos"
  allAlbums:Array<Album>;
  allPhotos:Array<Photo>;

  getAlbums():Array<Album>{
    let jsonConvert: JsonConvert = new JsonConvert();
    jsonConvert.ignorePrimitiveChecks = false; // don't allow assigning number to string etc.
    // jsonConvert.operationMode = OperationMode.LOGGING; // print some debug data
    jsonConvert.valueCheckingMode = ValueCheckingMode.DISALLOW_NULL; // never allow null
    let albums:Array<Album>;
    this.httpclient.get(this.albumsUrl).subscribe(
      (data: any)=>{
        try{
          albums=<Album[]>jsonConvert.deserialize(data,Album);
          this.allAlbums=albums;
          return albums
        }catch(e){

        }
       
      },
      (error:any)=>{
        console.log(error);
      }
     
    );
  return albums;

  }

  getPhotos():Array<Photo>{
    let jsonConvert = new JsonConvert();
    let photos:Array<Photo>;
    this.httpclient.get(this.photosUrl).subscribe((data:any)=>{
        photos=<Photo[]>jsonConvert.deserialize(data,Photo);
        this.allPhotos=photos;
        return photos;
    },(error)=>{
      console.log(error);
    }
  )
    
    return this.allPhotos;
  }

   
  main():void{
    this.getAlbums();
    this.getPhotos();
    this.allAlbums.forEach(album => {
      this.allPhotos.forEach(photo=>{
        if(photo.albumId==album.id){
          album.thumbnail=photo.thumbnailUrl
        }
      }

      )
    });

      }

  
}


@JsonObject("Album")
export class Album{

  @JsonProperty("userId",Number)
  userId:Number = undefined;

  @JsonProperty("id",Number)
  id:Number = undefined;

  @JsonProperty("title",String)
  title:String= undefined;

  thumbnail:String = undefined;
}

export class Photo{
  
  @JsonProperty("albumId", Number)
  albumId:Number=undefined;

  @JsonProperty("id",Number)
  id:Number = undefined;

  @JsonProperty("url",String)
  url:String = undefined;

  @JsonProperty("title",String)
  title:String= undefined;

  @JsonProperty("thumbnailUrl",String)
  thumbnailUrl:String= undefined;


}