import { Component, OnInit } from '@angular/core';
import { HttpClient } from '../../../node_modules/@angular/common/http';
import {JsonObject, JsonProperty, JsonConvert, OperationMode, ValueCheckingMode} from "json2typescript";
import { resolve } from 'dns';
import { reject } from '../../../node_modules/@types/q';

@Component({
  selector: 'app-photo-component',
  templateUrl: './photo-component.component.html',
  styleUrls: ['./photo-component.component.css']
})
export class PhotoComponentComponent implements OnInit {

  constructor(private httpclient: HttpClient) { }

  ngOnInit() {
  }

  albumsUrl = "https://jsonplaceholder.typicode.com/albums";
  photosUrl = "https://jsonplaceholder.typicode.com/photos"
  allAlbums:Array<Album>;
  allPhotos:Array<Photo>;

  fetchDetails(){
    let jsonConvert = new JsonConvert();
    return this.httpclient.get(this.photosUrl).subscribe((data)=>{
      this.allPhotos=<Photo[]>jsonConvert.deserialize(data,Photo)
      this.httpclient.get(this.albumsUrl).subscribe((data)=>{
        this.allAlbums=<Album[]>jsonConvert.deserialize(data,Album)
        this.allAlbums.forEach(album => {
          album.thumbnail=this.allPhotos.find(x=> x.id==album.id).thumbnailUrl
        });
      })
    })
  }

  
  getPhotos(){
    this.fetchDetails()
    return this.allPhotos;    
  }
  
}


@JsonObject("Album")
export class Album{

  @JsonProperty("userId",Number)
  userId:Number = undefined;

  @JsonProperty("id",Number)
  id:Number = undefined;

  @JsonProperty("title",String)
  title:String= undefined;

  thumbnail:String = undefined;
}

export class Photo{
  
  @JsonProperty("albumId", Number)
  albumId:Number=undefined;

  @JsonProperty("id",Number)
  id:Number = undefined;

  @JsonProperty("url",String)
  url:String = undefined;

  @JsonProperty("title",String)
  title:String= undefined;

  @JsonProperty("thumbnailUrl",String)
  thumbnailUrl:String= undefined;


}